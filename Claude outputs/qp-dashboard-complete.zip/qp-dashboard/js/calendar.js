/* calendar.js
 * "Calendar" card on the dashboard: a week strip + the agenda for the picked day.
 * Edit the EVENTS array to change what shows up. `day` is an offset from today
 * (0 = today, 1 = tomorrow, -1 = yesterday) so the prototype always looks current.
 * type: "meeting" | "event" | "deadline"
 */
(function () {
  const EVENTS = [
    { day: 0, time: "09:30", end: "09:45", title: "Engineering stand-up", type: "meeting", where: "Teams" },
    { day: 0, time: "13:00", end: "14:00", title: "POC plan review with Maja", type: "meeting", where: "Room Kepler" },
    { day: 0, time: "16:00", end: "", title: "Security key registration closes", type: "deadline", where: "IT support" },
    { day: 1, time: "10:00", end: "11:30", title: "QualiPro Core v4.2 walkthrough", type: "event", where: "Auditorium + stream" },
    { day: 1, time: "15:00", end: "15:30", title: "1:1 with team lead", type: "meeting", where: "Teams" },
    { day: 2, time: "12:00", end: "13:00", title: "Lunch & learn: secure prompts", type: "event", where: "Kitchen" },
    { day: 4, time: "09:00", end: "10:00", title: "Sprint planning", type: "meeting", where: "Room Kepler" },
    { day: 4, time: "17:00", end: "", title: "Q4 OKR draft due", type: "deadline", where: "Projects" },
    { day: 6, time: "16:00", end: "18:00", title: "Friday after-work", type: "event", where: "Rooftop" },
    { day: 8, time: "11:00", end: "12:00", title: "Architecture guild", type: "meeting", where: "Teams" },
    { day: -2, time: "14:00", end: "15:00", title: "Retro", type: "meeting", where: "Room Kepler" },
  ];
  const TYPE_LABEL = { meeting: "Meeting", event: "Event", deadline: "Deadline" };
  const el = {
    month: document.getElementById("cal-month"),
    week: document.getElementById("cal-week"),
    agenda: document.getElementById("cal-agenda"),
  };
  if (!el.week) return;

  const DAY = 864e5;
  const startOfDay = (d) => new Date(d.getFullYear(), d.getMonth(), d.getDate());
  const today = startOfDay(new Date());
  const addDays = (d, n) => new Date(d.getFullYear(), d.getMonth(), d.getDate() + n);
  const mondayOf = (d) => addDays(d, -((d.getDay() + 6) % 7));
  const offset = (d) => Math.round((startOfDay(d) - today) / DAY);
  const eventsOn = (d) => EVENTS.filter((e) => e.day === offset(d)).sort((a, b) => a.time.localeCompare(b.time));

  let selected = today;
  let weekStart = mondayOf(today);

  function render() {
    const days = Array.from({ length: 7 }, (_, n) => addDays(weekStart, n));
    const months = [...new Set(days.map((d) => d.toLocaleDateString("en-GB", { month: "long" })))];
    el.month.textContent = `${months.join(" – ")} ${days[6].getFullYear()}`;

    el.week.innerHTML = days
      .map((d) => {
        const evs = eventsOn(d),
          isSel = +d === +selected,
          isToday = +d === +today;
        const dots = evs
          .slice(0, 3)
          .map((e) => `<i class="t-${e.type}"></i>`)
          .join("");
        return `<button type="button" role="tab" class="cal-day${isSel ? " sel" : ""}${isToday ? " today" : ""}"
          aria-selected="${isSel}" data-off="${offset(d)}"
          aria-label="${d.toLocaleDateString("en-GB", { weekday: "long", day: "numeric", month: "long" })}, ${evs.length} item${evs.length === 1 ? "" : "s"}">
          <small>${d.toLocaleDateString("en-GB", { weekday: "short" }).slice(0, 2)}</small>
          <b>${d.getDate()}</b><span class="dots">${dots}</span></button>`;
      })
      .join("");

    const evs = eventsOn(selected);
    const off = offset(selected);
    const heading =
      off === 0 ? "Today" : off === 1 ? "Tomorrow" : off === -1 ? "Yesterday"
        : selected.toLocaleDateString("en-GB", { weekday: "long", day: "numeric", month: "short" });
    el.agenda.innerHTML =
      `<div class="cal-agenda-head">${heading}<span>${evs.length || "No"} item${evs.length === 1 ? "" : "s"}</span></div>` +
      (evs.length
        ? evs
            .map(
              (e) => `<button type="button" class="cal-event t-${e.type}" data-title="${e.title}">
              <span class="cal-time">${e.time}${e.end ? `<small>${e.end}</small>` : ""}</span>
              <span class="cal-copy"><strong>${e.title}</strong><small>${TYPE_LABEL[e.type]} · ${e.where}</small></span>
            </button>`,
            )
            .join("")
        : `<div class="cal-empty">Nothing scheduled. Enjoy the focus time.</div>`);
  }

  el.week.addEventListener("click", (e) => {
    const b = e.target.closest(".cal-day");
    if (!b) return;
    selected = addDays(today, +b.dataset.off);
    render();
    el.week.querySelector(".cal-day.sel")?.focus();
  });
  el.week.addEventListener("keydown", (e) => {
    const step = { ArrowLeft: -1, ArrowRight: 1 }[e.key];
    if (!step) return;
    e.preventDefault();
    selected = addDays(selected, step);
    if (selected < weekStart || selected >= addDays(weekStart, 7)) weekStart = mondayOf(selected);
    render();
    el.week.querySelector(".cal-day.sel")?.focus();
  });
  el.agenda.addEventListener("click", (e) => {
    const b = e.target.closest(".cal-event");
    if (b && typeof notify === "function") notify(`Opening “${b.dataset.title}”`);
  });
  const shiftWeek = (n) => {
    weekStart = addDays(weekStart, 7 * n);
    selected = addDays(selected, 7 * n);
    render();
  };
  document.getElementById("cal-prev").addEventListener("click", () => shiftWeek(-1));
  document.getElementById("cal-next").addEventListener("click", () => shiftWeek(1));
  document.getElementById("cal-today").addEventListener("click", () => {
    selected = today;
    weekStart = mondayOf(today);
    render();
  });

  render();
})();
