/* app.js
 * General page behaviour: helpers, toasts, chat box, card tilt,
 * light/dark mode switch, and the notification + profile dropdowns.
 */
const $ = (s) => document.querySelector(s),
  $$ = (s) => document.querySelectorAll(s);
const reduce = () => matchMedia("(prefers-reduced-motion: reduce)").matches;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

/* ---------- Toasts & prototype actions ---------- */
const toast = $("#toast");
let toastTimer;
function notify(m) {
  toast.textContent = m;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 2200);
}
$$("[data-toast]").forEach((el) =>
  el.addEventListener("click", () => {
    notify(el.dataset.toast);
    closeMenus();
  }),
);
$$("[data-prompt]").forEach((el) =>
  el.addEventListener("click", () => {
    $("#chat-input").value = el.dataset.prompt;
    $("#chat-input").focus();
  }),
);
$("#chat-input").addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    $("#chat-form").requestSubmit();
  }
});
$("#chat-form").addEventListener("submit", (e) => {
  e.preventDefault();
  const input = $("#chat-input"),
    text = input.value.trim();
  if (!text) {
    input.focus();
    return;
  }
  input.value = "";
  qpChat.ask(text); // adds it to the thread and opens the AI drawer (js/chat.js)
});

const stage = document.querySelector(".tilt");
stage.addEventListener("pointermove", (e) => {
  if (
    matchMedia("(prefers-reduced-motion: reduce)").matches ||
    document.body.classList.contains("is-holding")
  )
    return;
  const r = stage.getBoundingClientRect(),
    x = (e.clientX - r.left) / r.width - 0.5,
    y = (e.clientY - r.top) / r.height - 0.5;
  stage.style.transform = `rotateX(${(-y * 1.8).toFixed(2)}deg) rotateY(${(x * 2.1).toFixed(2)}deg)`;
});
stage.addEventListener("pointerleave", () => (stage.style.transform = ""));

/* ---------- Light / dark mode ---------- */
const root = document.documentElement;
function syncThemeUI() {
  const dark = root.dataset.theme === "dark";
  $("#theme-btn").setAttribute("aria-label", dark ? "Switch to light mode" : "Switch to dark mode");
  const mi = $("#menu-theme");
  mi.querySelector("span").textContent = dark ? "Light mode" : "Dark mode";
  mi.querySelector("use").setAttribute("href", dark ? "#i-sun" : "#i-moon");
  $$("[data-theme-set]").forEach((b) => b.setAttribute("aria-pressed", b.dataset.themeSet === root.dataset.theme));
}
function setTheme(t) {
  root.dataset.theme = t;
  try {
    localStorage.setItem("qp-theme", t);
  } catch (e) {}
  syncThemeUI();
}
function toggleTheme() {
  setTheme(root.dataset.theme === "dark" ? "light" : "dark");
}
$("#theme-btn").addEventListener("click", toggleTheme);
$("#menu-theme").addEventListener("click", toggleTheme);
document.addEventListener("keydown", (e) => {
  if (
    e.key.toLowerCase() === "d" &&
    !e.metaKey &&
    !e.ctrlKey &&
    !e.altKey &&
    !/INPUT|TEXTAREA/.test(document.activeElement.tagName) &&
    !document.body.classList.contains("is-touring")
  )
    toggleTheme();
});
syncThemeUI();

/* ---------- Notification & profile menus ---------- */
const menus = [
  [$("#notif-btn"), $("#notif-menu")],
  [$("#profile-btn"), $("#profile-menu")],
];
function closeMenus(except) {
  menus.forEach(([b, m]) => {
    if (m !== except) {
      m.classList.remove("open");
      b.setAttribute("aria-expanded", "false");
    }
  });
}
menus.forEach(([b, m]) =>
  b.addEventListener("click", (e) => {
    e.stopPropagation();
    const open = !m.classList.contains("open");
    closeMenus(m);
    m.classList.toggle("open", open);
    b.setAttribute("aria-expanded", open);
  }),
);
menus.forEach(([, m]) => m.addEventListener("click", (e) => e.stopPropagation()));
document.addEventListener("click", () => closeMenus());
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape") closeMenus();
});
$("#mark-read").addEventListener("click", () => {
  $$(".notif.unread").forEach((n) => n.classList.remove("unread"));
  $("#notif-badge").hidden = true;
  $("#notif-btn").setAttribute("aria-label", "Notifications");
  notify("All caught up");
});

/* ---------- Time-based greeting ---------- */
function updateGreeting() {
  const h = new Date().getHours();
  const text = h >= 5 && h < 12 ? "Good morning" : h >= 12 && h < 18 ? "Good afternoon" : "Good evening";
  const el = $("#greet-text");
  if (el && el.textContent !== text) el.textContent = text;
}
updateGreeting();
setInterval(updateGreeting, 60 * 1000);

/* ---------- Sidebar views (Dashboard, News, Handbook, IT, Projects, Settings) ---------- */
const VIEWS = {
  dashboard: "Dashboard",
  news: "News & information",
  handbook: "Employee handbook",
  it: "IT support",
  projects: "Projects",
  settings: "Settings",
};
function showView(name, { push = true } = {}) {
  if (!VIEWS[name]) name = "dashboard";
  $$(".view").forEach((v) => (v.hidden = v.dataset.view !== name));
  $$(".nav [data-view-link]").forEach((b) => {
    const on = b.dataset.viewLink === name;
    b.classList.toggle("active", on);
    if (on) b.setAttribute("aria-current", "page");
    else b.removeAttribute("aria-current");
  });
  $(".crumb b").textContent = VIEWS[name];
  document.title = (name === "dashboard" ? "" : VIEWS[name] + " · ") + "QualiPro · AI Knowledge Hub";
  if (push && location.hash !== "#" + name) history.pushState(null, "", "#" + name);
  closeMenus();
  scrollTo({ top: 0 });
}
$$("[data-view-link]").forEach((b) => b.addEventListener("click", () => showView(b.dataset.viewLink)));
addEventListener("popstate", () => showView(location.hash.slice(1), { push: false }));
showView(location.hash.slice(1), { push: false });

/* Settings controls */
$$("[data-theme-set]").forEach((b) => b.addEventListener("click", () => setTheme(b.dataset.themeSet)));
$$(".switch").forEach((sw) =>
  sw.addEventListener("click", () => {
    const on = sw.getAttribute("aria-checked") !== "true";
    sw.setAttribute("aria-checked", on);
    notify(`${sw.getAttribute("aria-label")} ${on ? "on" : "off"}`);
  }),
);
syncThemeUI();
