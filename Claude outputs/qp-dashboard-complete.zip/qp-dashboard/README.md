# QualiPro Knowledge Hub – dashboard

Serve this folder with a web server and open it in a browser:

    cd qp-dashboard && python3 -m http.server 5178      →  http://localhost:5178

(Opening index.html by double-click also works, but the browser then blocks the
3D model and the 2D robot image is shown instead.)

```
index.html          Page markup (sections are marked with <!-- ===== ... ===== --> comments)
css/
  base.css          Layout + DARK mode (default). Colour tokens are at the top in :root
  mascot.css        QP robot in the chat card, its speech bubble, and the 3D model
  topbar.css        Theme toggle, tour button, notifications + profile dropdowns
  tour.css          First-time tour: spotlight, flying robot, tooltip
  features.css      Search field, command palette, modal, dashboard widgets, AI drawer
  light.css         LIGHT mode (qualipro.se style). Only applies when light mode is on
js/
  app.js            Toasts, chat box, theme switch, dropdown menus, views
  calendar.js       Calendar card: week strip + agenda (edit the EVENTS array)
  robot.js          Robot flight animation + drag-and-drop
  tour.js           Tour steps (edit the STEPS array) and tour logic
  features.js       Command palette (Cmd/Ctrl+K), modal + DOCS, checklist, quick access,
                    activity feed, sidebar quick links + their Edit button
  chat.js           QualiChat drawer: simulated answers with citations + citation inspector
  mascot3d.js       3D robot: POSES, EYES, QUOTES and its behaviour
  vendor/           <model-viewer> 4.0.0, local copy (no internet needed)
assets/
  qp.glb            The 3D robot
  qp-robot.webp     2D robot, shown while the model loads or if it cannot load
```

Load order matters: CSS and scripts as listed in `index.html`.

Handy:
- Brand colours: `--gold`, `--bg`, `--panel`… in `base.css` (dark) and `light.css` (light).
- See the tour again: run `qpTour.reset()` in the browser console and reload.
- Add a tool or document: add an entry to `DOCS` in `js/features.js`.
- Checklist: `TASKS` in `js/features.js`. Activity feed: `FEED_SEED` / `FEED_POOL`.
- Chat answers are simulated: `KB` and `TOPICS` in `js/chat.js`.
- Robot: `POSES`, `EYES`, `QUOTES`, `IDLE_AFTER` in `js/mascot3d.js`.
- Saved in the browser (localStorage): `qp-theme`, `qp-pins`, `qp-recent`,
  `qp-onboarding`, `qp-quicklinks`.
